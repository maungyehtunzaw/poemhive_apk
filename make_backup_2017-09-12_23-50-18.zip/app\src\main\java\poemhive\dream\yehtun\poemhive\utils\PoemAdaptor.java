package poemhive.dream.yehtun.poemhive.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import poemhive.dream.yehtun.poemhive.PoemsActivity;
import poemhive.dream.yehtun.poemhive.R;
import poemhive.dream.yehtun.poemhive.data.PoemData;

/**
 * Created by Ye Htun on 2017-09-01.
 */

public class PoemAdaptor extends RecyclerView.Adapter<PoemAdaptor.PoemViewHolder> {
    Context context;
    ArrayList<PoemData> poemDatas;

    public PoemAdaptor(Context context, ArrayList<PoemData> poemDatas) {
        this.context = context;
        this.poemDatas = poemDatas;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public ArrayList<PoemData> getPoemDatas() {
        return poemDatas;
    }

    public void setPoemDatas(ArrayList<PoemData> poemDatas) {
        this.poemDatas = poemDatas;
    }

    @Override
    public PoemAdaptor.PoemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.poemcard, parent, false);
        return new PoemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(PoemAdaptor.PoemViewHolder holder, int position) {
        //holder.imgPoem.setImageResource(poemDatas.get(position).getImage());
        Picasso.with(context)
                .load(poemDatas.get(position).getImage())
                .resize(50, 50)
                .centerCrop()
                .into(holder.imgPoem);
        holder.txtTitle.setText(poemDatas.get(position).getTitle());
        holder.txtCreated.setText(poemDatas.get(position).getCreated());

    }

    @Override
    public int getItemCount() {
        return (poemDatas==null) ? 0:poemDatas.size();
    }

    public class PoemViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPoem;
        TextView txtTitle, txtCreated;

        public PoemViewHolder(View itemView) {
            super(itemView);
            imgPoem = (ImageView) itemView.findViewById(R.id.iv_poemimg);
            txtTitle = (TextView) itemView.findViewById(R.id.tv_poemtitle);
            txtCreated = (TextView) itemView.findViewById(R.id.tv_poemcreated);
        }
    }
}
